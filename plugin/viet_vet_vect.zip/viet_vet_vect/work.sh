# https://www.qgistutorials.com/en/docs/3/building_a_python_plugin.html
# https://courses.spatialthoughts.com/pyqgis-masterclass.html


cd /home/sn/dev/aote/Para/Vietnam/vietnam_github/viet_vet_vect
pb_tool compile ; cp -r /home/sn/dev/aote/Para/Vietnam/vietnam_github/viet_vet_vect /home/sn/.local/share/QGIS/QGIS3/profiles/default/python/plugins

